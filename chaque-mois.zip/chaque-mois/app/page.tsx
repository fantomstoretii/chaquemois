import PayButton from "@/components/PayButton";

const benefices = [
  {
    titre: "Une minute de saisie",
    detail:
      "Tu rentres les chiffres du mois — le reste est automatique. Pas de mise en page à refaire.",
  },
  {
    titre: "Envoyé le 1er du mois",
    detail:
      "Programmé une fois, expédié sans que tu y repenses. Fini le rapport envoyé le 14 avec des excuses.",
  },
  {
    titre: "Tu sais qu'il a été lu",
    detail: "Un accusé de lecture t'indique quand le client a ouvert son bilan.",
  },
];

export default function Home() {
  return (
    <main className="min-h-screen">
      <section className="mx-auto max-w-2xl px-6 pt-14 pb-10 sm:pt-20">
        <p className="text-sm font-medium text-sauge">Chaque Mois</p>

        <h1 className="mt-4 font-display text-4xl font-semibold leading-[1.1] text-encre sm:text-5xl">
          Le bilan mensuel envoyé sans y penser.
        </h1>

        <p className="mt-5 max-w-md text-lg leading-relaxed text-encre/80">
          Tu trouves les prix les plus bas pour tes clients — voyages,
          carburant, activités. Le bilan qui prouve ce qu&apos;ils y ont
          gagné se fait à la main, en retard, ou pas du tout. C&apos;est là
          que le contrat s&apos;arrête.
        </p>

        {/* Preuve visuelle : à quoi ressemble le rapport livré */}
        <div className="mt-10 rounded-sm border border-ligne bg-white p-6 shadow-[0_1px_0_0_rgba(28,31,38,0.04)]">
          <div className="flex items-baseline justify-between border-b border-ligne pb-4">
            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-encre/50">
                Bilan de mars — Client Dupont
              </p>
              <p className="mt-1 font-display text-sm text-encre/70">
                Envoyé automatiquement le 1er avril
              </p>
            </div>
          </div>
          <div className="mt-4 flex items-end justify-between">
            <p className="text-sm text-encre/70">Économisé ce mois-ci</p>
            <p className="tabular font-display text-3xl font-semibold text-sauge">
              312 €
            </p>
          </div>
          <div className="mt-3 space-y-1.5 text-sm text-encre/60">
            <div className="tabular flex justify-between">
              <span>Vols Lyon–Porto</span>
              <span>91 €</span>
            </div>
            <div className="tabular flex justify-between">
              <span>Carburant (mois)</span>
              <span>64 €</span>
            </div>
            <div className="tabular flex justify-between">
              <span>Activités weekend</span>
              <span>157 €</span>
            </div>
          </div>
        </div>

        <div className="mt-10">
          <PayButton />
          <p className="mt-3 text-sm text-encre/50">
            39 €/mois, jusqu&apos;à dix clients suivis. Sans engagement.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-2xl px-6 pb-16">
        <div className="border-t border-ligne pt-10">
          <ul className="space-y-7">
            {benefices.map((b) => (
              <li key={b.titre} className="border-l-2 border-sauge/30 pl-5">
                <p className="font-display text-lg font-semibold text-encre">
                  {b.titre}
                </p>
                <p className="mt-1 text-encre/70">{b.detail}</p>
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-12 border-t border-ligne pt-10 text-center">
          <PayButton className="inline-flex w-full items-center justify-center rounded-sm bg-encre px-8 py-4 text-base font-semibold text-papier transition-colors hover:bg-sauge sm:w-auto" />
        </div>
      </section>

      <footer className="mx-auto max-w-2xl px-6 pb-10 text-sm text-encre/40">
        <p>Chaque Mois</p>
      </footer>
    </main>
  );
}
