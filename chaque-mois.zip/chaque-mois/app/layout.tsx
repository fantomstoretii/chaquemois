import type { Metadata } from "next";
import { Fraunces, Inter } from "next/font/google";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  weight: ["500", "600"],
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  weight: ["500", "600"],
});

const siteUrl = "https://chaque-mois.vercel.app"; // à remplacer par ton vrai domaine une fois en ligne

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: "Chaque Mois — Le bilan mensuel envoyé sans y penser",
  description:
    "Le rapport que tes clients réclament, généré et envoyé automatiquement chaque mois. 39 €/mois pour dix clients suivis.",
  openGraph: {
    title: "Chaque Mois — Le bilan mensuel envoyé sans y penser",
    description:
      "Le rapport que tes clients réclament, généré et envoyé automatiquement chaque mois.",
    url: siteUrl,
    siteName: "Chaque Mois",
    locale: "fr_FR",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Chaque Mois — Le bilan mensuel envoyé sans y penser",
    description:
      "Le rapport que tes clients réclament, généré et envoyé automatiquement chaque mois.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr">
      <body className={`${fraunces.variable} ${inter.variable} font-sans antialiased`}>
        {children}
      </body>
    </html>
  );
}
