import Link from "next/link";

export default function NotFound() {
  return (
    <main className="mx-auto flex min-h-screen max-w-2xl flex-col justify-center px-6 py-16">
      <h1 className="font-display text-3xl font-semibold text-encre sm:text-4xl">
        Cette page n&apos;existe pas.
      </h1>
      <p className="mt-4 text-encre/70">
        Le lien est peut-être incomplet ou périmé.
      </p>
      <Link
        href="/"
        className="mt-8 inline-block text-sm font-medium text-sauge underline underline-offset-4"
      >
        Retour à l&apos;accueil
      </Link>
    </main>
  );
}
