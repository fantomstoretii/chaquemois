import Link from "next/link";
import PayButton from "@/components/PayButton";

export default function Annule() {
  return (
    <main className="mx-auto flex min-h-screen max-w-2xl flex-col justify-center px-6 py-16">
      <h1 className="font-display text-3xl font-semibold text-encre sm:text-4xl">
        Paiement annulé
      </h1>
      <p className="mt-4 max-w-md text-encre/70">
        Rien n&apos;a été débité. Tu peux réessayer quand tu veux.
      </p>
      <div className="mt-8">
        <PayButton />
      </div>
      <Link
        href="/"
        className="mt-6 inline-block text-sm font-medium text-sauge underline underline-offset-4"
      >
        Retour à l&apos;accueil
      </Link>
    </main>
  );
}
