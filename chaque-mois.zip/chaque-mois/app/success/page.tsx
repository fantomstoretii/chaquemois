import Stripe from "stripe";
import Link from "next/link";

export const dynamic = "force-dynamic";

async function getSessionEmail(sessionId: string | undefined) {
  if (!sessionId || !process.env.STRIPE_SECRET_KEY) return null;
  try {
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    const session = await stripe.checkout.sessions.retrieve(sessionId);
    return session.customer_details?.email ?? null;
  } catch (err) {
    console.error("Impossible de récupérer la session Stripe :", err);
    return null;
  }
}

export default async function Success({
  searchParams,
}: {
  searchParams: Promise<{ session_id?: string }>;
}) {
  const { session_id } = await searchParams;
  const email = await getSessionEmail(session_id);

  return (
    <main className="mx-auto flex min-h-screen max-w-2xl flex-col justify-center px-6 py-16">
      <p className="text-sm font-medium text-sauge">Paiement confirmé</p>
      <h1 className="mt-4 font-display text-3xl font-semibold text-encre sm:text-4xl">
        Merci, c&apos;est enregistré.
      </h1>
      <p className="mt-4 max-w-md text-encre/70">
        {email
          ? `Ton accès arrive par email à ${email} sous 24h.`
          : "Ton accès arrive par email sous 24h."}
      </p>
      <p className="mt-2 max-w-md text-sm text-encre/50">
        Une question en attendant ? Réponds directement à l&apos;email de
        confirmation Stripe que tu viens de recevoir.
      </p>
      <Link
        href="/"
        className="mt-10 inline-block text-sm font-medium text-sauge underline underline-offset-4"
      >
        Retour à l&apos;accueil
      </Link>
    </main>
  );
}
