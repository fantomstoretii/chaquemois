"use client";

import { useState } from "react";

export default function PayButton({ className }: { className?: string }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleClick() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/checkout", { method: "POST" });
      const data = await res.json();
      if (!res.ok || !data.url) {
        throw new Error(data.error || "Le paiement n'a pas pu démarrer.");
      }
      window.location.href = data.url;
    } catch {
      setError("Le paiement n'a pas pu démarrer. Réessaie dans un instant.");
      setLoading(false);
    }
  }

  return (
    <div>
      <button
        onClick={handleClick}
        disabled={loading}
        className={
          className ??
          "inline-flex w-full items-center justify-center rounded-sm bg-encre px-8 py-4 text-base font-semibold text-papier transition-colors hover:bg-sauge disabled:opacity-60 sm:w-auto"
        }
      >
        {loading ? "Redirection vers le paiement…" : "Démarrer — 39 €/mois"}
      </button>
      {error && <p className="mt-3 text-sm text-brique">{error}</p>}
    </div>
  );
}
