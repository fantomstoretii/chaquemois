# Chaque Mois — Étape 1

Une page, un bouton, un paiement Stripe. Pas de base de données pour l'instant.

## Ce que tu as dans les mains

- `app/page.tsx` — la landing page
- `app/api/checkout/route.ts` — crée le paiement Stripe côté serveur
- `app/success/page.tsx` — page après paiement réussi
- `app/annule/page.tsx` — page si le client annule
- `app/not-found.tsx` — page 404 propre

## Marche à suivre, une action à la fois

### 1. Créer un compte GitHub (si tu n'en as pas)
Va sur github.com → « Sign up ». C'est gratuit. Dis-moi quand c'est fait.

### 2. Mettre ce code sur GitHub
Dans ce dossier, ouvre un terminal et tape :
```
git init
git add .
git commit -m "Étape 1 : landing + paiement"
```
Puis sur GitHub, clique « New repository », nomme-le `chaque-mois`, ne coche aucune case (pas de README), crée-le. GitHub t'affichera des commandes du type :
```
git remote add origin https://github.com/TON-PSEUDO/chaque-mois.git
git push -u origin main
```
Copie-colle-les dans ton terminal.

### 3. Créer un compte Vercel
Va sur vercel.com → « Sign up » → choisis « Continue with GitHub ». Ça relie directement les deux comptes.

### 4. Importer le projet sur Vercel
Sur le tableau de bord Vercel, clique « Add New… » → « Project » → choisis ton dépôt `chaque-mois` → « Import ». Ne clique pas encore sur « Deploy », on va d'abord ajouter les clés Stripe (étape suivante), sinon le site plantera au premier essai.

### 5. Créer ton compte Stripe et récupérer les clés
1. Va sur stripe.com → crée un compte.
2. Reste en **mode Test** (interrupteur en haut à droite du tableau de bord, il doit afficher « Mode test »).
3. Menu de gauche → **Développeurs** → **Clés API** → copie la « Clé secrète » (elle commence par `sk_test_...`).
4. Menu de gauche → **Catalogue de produits** → « + Ajouter un produit » → nomme-le « Chaque Mois », prix **39 €**, récurrence **Mensuelle** → Enregistrer.
5. Clique sur le produit créé, tu verras un ID qui commence par `price_...` → copie-le.

### 6. Ajouter ces clés dans Vercel
Retourne sur la page d'import de ton projet Vercel (étape 4) → section « Environment Variables » → ajoute :
- `STRIPE_SECRET_KEY` = la clé `sk_test_...`
- `STRIPE_PRICE_ID` = l'ID `price_...`

Puis clique **Deploy**. Attends 1 à 2 minutes.

### 7. Tester le paiement
Vercel te donne une adresse en `.vercel.app`. Ouvre-la sur ton téléphone.
1. Clique sur le bouton de paiement.
2. Stripe t'amène sur sa page de paiement. Utilise une carte de test :
   - Numéro : `4242 4242 4242 4242`
   - Date : n'importe quelle date future
   - CVC : n'importe quel 3 chiffres
3. Tu dois arriver sur la page « Merci, c'est enregistré ».

Dis-moi quand ce test passe — on bascule ensuite en mode réel (étape 2 du plan) et on ajoute le webhook qui confirme le paiement côté serveur, indispensable avant d'encaisser du vrai argent.

## En local (optionnel, si tu veux tester avant de déployer)
```
npm install
cp .env.example .env.local   # puis remplis les deux valeurs
npm run dev
```
Ouvre http://localhost:3000
